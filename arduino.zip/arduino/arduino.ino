#include <Arduino_FreeRTOS.h>
#include <DHT.h>
#include <SPI.h>
#include <SD.h>

#define DHTPIN 2
#define DHTTYPE DHT11
#define LDRPIN A0
const int chipSelect = 4;

// FreeRTOS task function declarations
void TaskReadSensors(void *pvParameters);
void TaskSerialTransmit(void *pvParameters);
void TaskSaveToSD(void *pvParameters);

// Global data matrix for thread sharing
struct EnvironmentMetrics {
  float temperature;
  float humidity;
  int brightness;
} currentMetrics;

void setup() {
  Serial.begin(9600);
  
  // Initialize the SPI communication channel for the memory card
  if (!SD.begin(chipSelect)) {
    // If the storage module is missing, operations continue via serial paths
    Serial.println("Storage module initialization failed");
  }

  // Instantiation of independent threads within the real time operating system
  xTaskCreate(TaskReadSensors, "ReadSensors", 128, NULL, 3, NULL);
  xTaskCreate(TaskSerialTransmit, "SerialTransmit", 128, NULL, 1, NULL);
  xTaskCreate(TaskSaveToSD, "SaveToSD", 256, NULL, 2, NULL); 
}

void loop() {
  // Bypassed entirely by the FreeRTOS multitasking scheduler
}

void TaskReadSensors(void *pvParameters) {
  (void) pvParameters;
  DHT dht(DHTPIN, DHTTYPE);
  dht.begin();

  for (;;) {
    float tempReading = dht.readTemperature();
    float humReading = dht.readHumidity();
    int lightReading = analogRead(LDRPIN);

    if (!isnan(tempReading) && !isnan(humReading)) {
      currentMetrics.temperature = tempReading;
      currentMetrics.humidity = humReading;
    }
    currentMetrics.brightness = lightReading;

    vTaskDelay(2000 / portTICK_PERIOD_MS);
  }
}

void TaskSerialTransmit(void *pvParameters) {
  (void) pvParameters;
  for (;;) {
    // Stream data packets out across the physical serial interface
    Serial.print(currentMetrics.temperature);
    Serial.print(",");
    Serial.print(currentMetrics.humidity);
    Serial.print(",");
    Serial.println(currentMetrics.brightness);

    vTaskDelay(2500 / portTICK_PERIOD_MS);
  }
}

void TaskSaveToSD(void *pvParameters) {
  (void) pvParameters;

  for (;;) {
    // Access the storage root directory in append mode
    File dataFile = SD.open("log.txt", FILE_WRITE);

    if (dataFile) {
      // Record comma separated telemetry records to physical disk array
      dataFile.print(currentMetrics.temperature);
      dataFile.print(",");
      dataFile.print(currentMetrics.humidity);
      dataFile.print(",");
      dataFile.println(currentMetrics.brightness);
      
      // Close the descriptor to execute file system synchronization
      dataFile.close();
    }

    vTaskDelay(10000 / portTICK_PERIOD_MS);
  }
}