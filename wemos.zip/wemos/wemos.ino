#include <ESP8266WiFi.h>
#include <ESP8266HTTPClient.h>
#include <WiFiClient.h>

// Network configuration credentials
const char* ssid = "YOUR_WIFI_SSID";
const char* password = "YOUR_WIFI_PASSWORD";

// Target REST API data ingestion endpoint
// Replace localhost or 127.0.0.1 with the actual IPv4 address of your host computer
const char* serverEndpoint = "http://192.168.1.XX:5000/api/classroom/telemetry"; 

void setup() {
  // Initialize serial interface at 9600 baud rate to match the Arduino Uno
  Serial.begin(9600);
  
  // Begin local wireless network connection sequence
  WiFi.begin(ssid, password);

  // Block execution until network authentication succeeds
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
  }
}

void loop() {
  // Check if character bytes are available in the hardware serial buffer
  if (Serial.available() > 0) {
    // Read the incoming byte stream until a newline character is reached
    String incomingPayload = Serial.readStringUntil('\n');
    incomingPayload.trim();

    // Identify position indexes of comma delimiters within the text string
    int firstComma = incomingPayload.indexOf(',');
    int secondComma = incomingPayload.indexOf(',', firstComma + 1);
    
    // Validate that the packet format contains all expected split markers
    if (firstComma != -1 && secondComma != -1) {
      // Isolate the substring segments for each environmental metric
      String temperatureVal = incomingPayload.substring(0, firstComma);
      String humidityVal = incomingPayload.substring(firstComma + 1, secondComma);
      String brightnessVal = incomingPayload.substring(secondComma + 1);

      // Verify active network link status prior to executing transmission
      if (WiFi.status() == WL_CONNECTED) {
        WiFiClient client;
        HTTPClient http;
        
        // Configure the destination endpoint route and protocol structures
        http.begin(client, serverEndpoint);
        http.addHeader("Content-Type", "application/json");
        
        // Synthesize the structured JSON payload string
        String jsonPayload = "{\"temperature\":" + temperatureVal + 
                             ",\"humidity\":" + humidityVal + 
                             ",\"brightness\":" + brightnessVal + "}";
        
        // Execute the HTTP POST command to pass data to the backend API
        int httpResponseCode = http.POST(jsonPayload);
        
        // Terminate the socket connection to clear network resources
        http.end();
      }
    }
  }
}